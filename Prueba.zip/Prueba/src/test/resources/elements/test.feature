Feature: Contiene la funcionalidad del menu Kraken


  Scenario: Consulta Item
    Given Se abre navegador y abre pagina web
    When Da clic en Menu Kraken
    When Da clic en Kraken
    When Da clic en Menu Filtros
    When Valida Texto
    When Selecciona Banner
    When Llenar Formulario
    When Da clic en Buscar
    Then Valida Datos
