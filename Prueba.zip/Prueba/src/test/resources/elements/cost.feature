Feature: Contiene la funcionalidad del menu Cost Analytics


  Scenario: Genera Informe
    Given Abrir Navegador
    When Da clic en Menu CA
    When Da clic en Opcion CA
    When Da clic en Alerta
    When Da clic en Gaps
    When Selecciona Fecha
    When Llenar Datos
    When Da clic en Generar Informe
    Then Valida Alerta
