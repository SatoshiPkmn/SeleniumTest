package pages.elements;

import io.cucumber.java.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import pages.BasePage;

import java.util.concurrent.TimeUnit;

public class CostElements extends BasePage {

    JavascriptExecutor js = (JavascriptExecutor) driver;

    private String botonCA = "//p[contains(text(), 'Cost Analytics')]";
    private String opcionCA = "//div/a/div/p[contains(text(), 'Cost Analytics')]";
    private String botonAceptar = "//button[@class='SD__clapp-btn primary rd']";
    private String botonGaps = "//a[contains(text(), 'Gaps')]";
    private String botonFecha = "//label[contains(text(), 'Seleccione un rango de fecha')]";
    private String botonFiltro = "//input[@placeholder='Filtrar por Buscar Proveedor']";
    private String botonGenerar = "//button[@class='SD__clapp-btn primary rd xl']";
    private String alerta = "//div[@class='w__toast info visible']";

    private String[] fecha = new String[] {

            "//span[contains(text(), '2024')]", //Año Ini
            "//span[contains(text(), 'ENE.')]", //Mes Ini//Año Fin
            "//span[contains(text(), '2024')]", //Año Fin
            "//span[contains(text(), 'OCT.')]" //Mes Fin

    };

    private String[] menu = new String[] {

            "//app-comobox-multi[@title='Formato']", //Formato
            "//app-combobox-single[@title='Tribu']", //Tribu
            "//app-combobox-single[@title='Mega Squad']", //MegaSquad
            "//app-combobox-single[@title='Squad']", //Squad
            "//app-combobox-single[@title='Departamento']", //Depto
            "//app-comobox-multi[@title='Categoría']", //Categoría
            "//app-combobox-single[@title='Buscar Proveedor]" //Proveedor

    };

    private String[] opcion = new String[]{

            "//*[@id='mat-mdc-checkbox-1']", //opFormato
            "//span[contains(.,'FOOD')]", //opTribu
            "//span[contains(., ' ABARROTES Y BEBIDAS ')]", //opMegaSquad
            "//span[contains(., ' BEBIDAS ')]", //opSquad
            //"//span[contains(., ' ABARROTES PROCESADOS ')]", //opDepto
            //"//*[@id='mat-mdc-checkbox-2']", //opCategoríaFUll
            "//span[contains(., ' 95-39 | AGUAS SABORIZADAS ')]", //opCategoría
            "//span[contains(., ' 310840-COCA COLA ')]" //opProveedor

    };

    public CostElements(WebDriver driver) {
        super(driver);  // Pasar el WebDriver al constructor de la superclase
    }

    public void haceClicEnCost() {
        js.executeScript("window.scrollBy(0,250)");
        clicElement(botonCA);
    }

    public void clicCost() {
        clicElement(opcionCA);
    }

    public void clicAlerta() throws PendingException, ElementClickInterceptedException, InterruptedException {
        Thread.sleep(5000);
        switchToiFrame("iframe");
            Find(botonAceptar);
            clicElement(botonAceptar);
        }

    public void clicGaps() {
        Find(botonGaps);
        clicElement(botonGaps);
    }

    public void clicFecha() throws InterruptedException{
        Find(botonFecha);
        clicElement(botonFecha);

        for (int i = 0; i <= 3; i++) {
            Find(fecha[i]);
            clicElement(fecha[i]);
            Thread.sleep(1000);
        }
    }

    public void llenarDatos() throws ElementClickInterceptedException, InterruptedException {
        for (int i = 0; i <= 5; i++) {
            if (i == 0){
                Find(menu[i]);
                clicElement(menu[i]);
                Find(opcion[i]);
                clicElement(opcion[i]);
                Find(botonAceptar);
                clicElement(botonAceptar);
                Thread.sleep(1000);
            }
            else if (i == 4){
                Find(opcion[i]);
                clicElement(opcion[i]);
                Find(botonAceptar);
                clicElement(botonAceptar);
                Thread.sleep(1000);
            }
            else if (i == 5){
                Find(botonFiltro);
                write(botonFiltro, "COCA COLA");
                Find(opcion[i]);
                clicElement(opcion[i]);
                Thread.sleep(1000);
            }
            else {
                Find(opcion[i]);
                clicElement(opcion[i]);
                Thread.sleep(1000);
            }
        }
    }

    public void clicGenerar(){
        Find(botonGenerar);
        clicElement(botonGenerar);
    }

    public void validaMsj() {
        Find(alerta);
        String msjAlerta = textFromElement(alerta);

        if (msjAlerta != null){
            System.out.println(msjAlerta + "\nSe está generando el Reporte");
        }
        else {
            System.out.println("No ha pasado nada");
        }
    }
}
