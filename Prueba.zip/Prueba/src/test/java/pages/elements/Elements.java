package pages.elements;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import pages.BasePage;

import java.util.concurrent.TimeUnit;

public class Elements extends BasePage {

    JavascriptExecutor js = (JavascriptExecutor) driver;

    private String botonKraken = "//p[contains(text(), 'Kraken')]";
    private String opcionKraken = "/html/body/div[19]/div/div[2]/div/div/div/a[1]";
    private String menuFiltros = "//button[@class='mat-focus-indicator btn-match-menu mat-raised-button mat-button-base']";
    private String campoFormato = "//*[@id='mat-select-value-1']";
    private String campoBanner = "//label[contains(text(), 'On Demand')]";
    private String botonAplicar = "//span[contains(text(), 'Aplicar')]";
    private String botonBuscar = "//span[contains(text(), 'Buscar')]";
    private String alerta = "//*[@id='toast-container']";

    private String[] menu = new String[] {

        "//*[@id='mat-select-value-3']", //Competidor
        "//*[@id='mat-select-value-5']", //Tribu
        "//*[@id='mat-select-value-11']", //SuperSquad
        "//*[@id='mat-select-value-7']" //Squad
    };

    private String[] opcion = new String[]{
            "//span[contains(text(), 'Amazon')]", //opCompetidor
            "/html/body/div[3]/div[2]/div/div/div/div/mat-option[3]/span", //opTribu
            "//span[contains(text(), 'E&T')]", //opSuperSquad
            "//span[contains(text(), 'JUGUETES Y DEPORTES')]" //opSquad
    };

    public Elements(WebDriver driver) {
        super(driver);  // Pasar el WebDriver al constructor de la superclase
    }

    public void haceClicEnKraken() {
        js.executeScript("window.scrollBy(0,250)");
        clicElement(botonKraken);
    }

    public void clicKraken() {
        clicElement(opcionKraken);
    }

    public void clicFiltros() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        switchToiFrame("iframe");
        clicElement(menuFiltros);
    }

    public void validaTexto() {
        String texto = textFromElement(campoFormato);

        if (texto.contains("Walmart")){
            System.out.println("La opción por defecto es: " + texto);
        }

        else {
            System.out.println("Walmart no es la opción por defecto: " + texto);
        }
    }

    public void clicBanner() {
        Find(campoBanner);
        clicElement(campoBanner);
    }

    public void llenarFormulario() {

        for (int i = 0; i <= 3; i++) {
            clicElement(menu[i]);
            clicElement(opcion[i]);
            clicElement(botonAplicar);
        }
    }

    public void clicBuscar() {
        clicElement(botonBuscar);
    }

    public void validaMsj() {
        Find(alerta);
        String msjAlerta = textFromElement(alerta);

        if (msjAlerta.contains("Resultados encontrados con éxito")){
            System.out.println(msjAlerta + "\nSe realiza la consulta correctamente");
        }
        else {
            System.out.println("No ha pasado nada");
        }
    }
}
