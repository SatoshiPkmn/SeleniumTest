package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

    protected WebDriver driver;
    private WebDriverWait wait;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 30);  // 10 segundos de espera
    }

    // Espera Explicita en todos los elementos que ocupamos
    public WebElement Find(String locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
    }

    // Clic a elementos
    public void clicElement(String locator) {
        Find(locator).click();
    }

    public void write(String locator, String textToWrite) {
        WebElement element = Find(locator);
        if (element != null) {
            element.clear();
            element.sendKeys(textToWrite);
        }
    }

    public void clicCheck(String locator) {
        WebElement checkBox = driver.findElement(By.xpath(locator));
        if(checkBox.isSelected() == true){
            checkBox.click();
        }
        else{
            System.out.println("La opción no se puede seleccionar");
        }
    }

    // ComboBox seleccionando opción por valor
    public void SelectComboByValue(String locator, String valueToSelect) {
        Select combo = new Select(Find(locator));
        combo.selectByValue(valueToSelect);
    }

    public String textFromElement(String locator) {
        return Find(locator).getText();
    }

    public void switchToiFrame(int iFrameIndex) {
        driver.switchTo().frame(iFrameIndex);
    }

    public void switchToiFrame(String iFrameName) {
        driver.switchTo().frame(iFrameName);
    }

    public void switchToAlert() {
        driver.switchTo().alert().accept();

    }

}
