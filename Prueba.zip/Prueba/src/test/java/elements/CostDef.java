package elements;

import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.elements.CostElements;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CostDef {

    private WebDriver driver;
    private CostElements demo;

    public CostDef() {
        System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
        driver = new ChromeDriver();
        demo = new CostElements(driver);
    }

    @Given("Abrir Navegador")
    public void the_user_is_on_the_login_page() throws InterruptedException {
        driver.get("https://compassapp.qa.prod.us.walmart.net/");
        driver.manage().window().maximize();
        Thread.sleep(10000);
    }

    @When("Da clic en Menu CA")
    public void clicMenuCA() {
        demo.haceClicEnCost();
    }

    @When("Da clic en Opcion CA")
    public void clicOpCA() {
        demo.clicCost();
    }

    @When("Da clic en Alerta")
    public void acceptAlert() throws InterruptedException{
        demo.clicAlerta();
    }

    @When ("Da clic en Gaps")
    public void clicGaps(){
        demo.clicGaps();
    }

    @When ("Selecciona Fecha")
    public void clicDate() throws InterruptedException{
        demo.clicFecha();
    }

    @When ("Llenar Datos")
    public void selectData() throws InterruptedException {
        demo.llenarDatos();
    }

    @When ("Da clic en Generar Informe")
    public void clicInforme(){
        demo.clicGenerar();
    }

    @Then ("Valida Alerta")
    public void validacion(){
        demo.validaMsj();
    }
}
