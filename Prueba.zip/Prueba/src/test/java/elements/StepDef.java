package elements;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.elements.Elements;

public class StepDef {

    private WebDriver driver;
    private Elements demo;

    public StepDef() {
        System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
        driver = new ChromeDriver();
        demo = new Elements(driver);
    }

    @Given("Se abre navegador y abre pagina web")
    public void the_user_is_on_the_login_page() throws InterruptedException {
        driver.get("https://compassapp.qa.prod.us.walmart.net/");
        driver.manage().window().maximize();
        Thread.sleep(9000);
    }

    @When("Da clic en Menu Kraken")
    public void clicMenuKraken() {
        demo.haceClicEnKraken();
    }

    @When("Da clic en Kraken")
    public void clicKraken() {
        demo.clicKraken();
    }

    @When("Da clic en Menu Filtros")
    public void clicMenuFiltros() {
        demo.clicFiltros();
    }

    @When("Valida Texto")
    public void extraeTexto(){
        demo.validaTexto();
    }

    @When("Selecciona Banner")
    public void seleccionaBanner(){
        demo.clicBanner();
    }

    @When("Llenar Formulario")
    public void formulario(){
        demo.llenarFormulario();
    }

    @When("Da clic en Buscar")
    public void clicBuscar(){
        demo.clicBuscar();
    }

    @When("Valida Datos")
    public void leyendaOk(){
        demo.validaMsj();
    }
}